// This culture information has been generated using the Mono class library
// licensed under the terms of the MIT X11 license.
// See: http://www.mono-project.com/FAQ:_Licensing

sffjs.registerCulture({
    name: "be",
    d: "dd.MM.yyyy",
    D: "d MMMM yyyy",
    t: "H:mm",
    T: "H:mm:ss",
    M: "d MMMM",
    Y: "MMMM yyyy",
    _am: "раніцы",
    _pm: "вечара",
    _r: ",",
    _cr: ",",
    _t: " ",
    _ct: " ",
    _c: "#,0.00 \u0027\u0027",
    _d: ["нд","пн","аў","ср","чц","пт","сб"],
    _D: ["нядзеля","панядзелак","аўторак","серада","чацвер","пятніца","субота"],
    _m: ["сту","лют","сак","кра","тра","чэр","ліп","жні","вер","кас","ліс","сне",""],
    _M: ["студзень","люты","сакавік","красавік","травень","чэрвень","ліпень","жнівень","верасень","кастрычнік","лістапад","снежань",""]
});

