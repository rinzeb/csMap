// This culture information has been generated using the Mono class library
// licensed under the terms of the MIT X11 license.
// See: http://www.mono-project.com/FAQ:_Licensing

sffjs.registerCulture({
    name: "gu",
    d: "dd-MM-yy",
    D: "dd MMMM yyyy",
    t: "HH:mm",
    T: "HH:mm:ss",
    M: "dd MMMM",
    Y: "MMMM, yyyy",
    _am: "પૂર્વ મધ્યાહ્ન",
    _pm: "ઉત્તર મધ્યાહ્ન",
    _r: ",",
    _cr: ",",
    _t: ",",
    _ct: ",",
    _c: "#,0.00 \u0027₹\u0027",
    _d: ["રવિ","સોમ","મંગળ","બુધ","ગુરુ","શુક્ર","શનિ"],
    _D: ["રવિવાર","સોમવાર","મંગળવાર","બુધવાર","ગુરુવાર","શુક્રવાર","શનિવાર"],
    _m: ["જાન્યુ","ફેબ્રુ","માર્ચ","એપ્રિલ","મે","જૂન","જુલાઈ","ઑગસ્ટ","સપ્ટે","ઑક્ટો","નવે","ડિસે",""],
    _M: ["જાન્યુઆરી","ફેબ્રુઆરી","માર્ચ","એપ્રિલ","મે","જૂન","જુલાઈ","ઑગસ્ટ","સપ્ટેમ્બર","ઑક્ટ્બર","નવેમ્બર","ડિસેમ્બર",""]
});

